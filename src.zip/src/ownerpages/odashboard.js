import React from "react";
import ONav from "./onav";
function Odashboard(){
    return(
        <>
        <ONav/>
        <h1>Odashboard</h1>
        </>
    )
}
export default Odashboard;