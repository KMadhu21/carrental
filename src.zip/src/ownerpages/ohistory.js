import React from "react";
import ONav from "./onav";
function Ohistory(){
    return(
        <>
        <ONav/>
        <h1>Ohistory</h1>
        </>
    )
}
export default Ohistory;