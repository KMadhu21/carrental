import React from "react";
import ONav from "./onav";
function Ostatus(){
    return(
        <>
        <ONav/>
        <h1>Ostatus</h1>
        </>
    )
}
export default Ostatus;